# Epsilon PHP

## En local

Déploiement de la BDD en local : sql.txt

Attention lors de l'inscription : envoie d'un mail.

- Soit paramétrer l'envoie de mail sur son local
- Soit valider l'inscription en copiant le lien présent dans la page de confirmation
