# Site de Vianney DRS
# Pour lancer le site il suffit de faire :
# php -S localhost:8000