<!DOCTYPE html>
<html>
<head>
    <title>360Learning</title>
    <link rel="stylesheet" type="text/css" href="css/index.css">
</head>
<body class="main_page">
<div class="center_page">
    <?php include 'header.html';?>
    <img src="upload/Quentin.png" class="logo">
    <img src="upload/vianney.jpg" class="logo">
        <h2>Quentin Caron</h2>
        <h2>Groupe : Yanis et Vladimir</h2>
        <h2>14 : Juste moins bon que les deux autres<br>mais mérite quand même plus (genre 19)</h2>
        <br>
    <bouton class="bouton_link">
        <a class="link" href="upload.php">
            Upload your file
        </a>
    </bouton>
    <?php include 'footer.html';?>
    </div>
    
    
</body>
</html>