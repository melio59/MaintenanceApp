<div class="w-full text-center">
    <h2 class="text-2xl font-semibold">EPSI | LON</h2>
</div>
<div class="w-full text-center">
    <h4 class="text-lg">Plateforme de peer-learning<br>EPSI Lille</h4>
</div>