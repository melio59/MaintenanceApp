<footer>
    <p>Copyright 2024 © Epsi Lille</p>
</footer>