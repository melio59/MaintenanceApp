<!DOCTYPE html>
<html>
    <head>
        <script src="https://cdn.tailwindcss.com"></script>
    </head>
    <header>
        <h1 class="font-bold text-3xl mt-4 mb-2">EPSI | LON</h1>
        <h2 class="mb-3">Plateforme de peer-learning<br>EPSI Lille</h2>
    </header>
</html>