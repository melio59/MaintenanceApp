<header>
    <h1>Epsi v2</h1>
    <p>Platforme de peer-learning</p>
    <p>EPSI Lille</p>
</header>