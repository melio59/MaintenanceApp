<footer>
    <p>Copyright © Epsi Lille 2024</p>
</footer>