<!DOCTYPE html>
<html>
<head>
    <title>360Learning</title>
    <link rel="stylesheet" type="text/css" href="css/index.css">
</head>
<body class="main_page">
<div class="center_page">
    <?php include 'header.html';?>
    <img src="upload/Quentin.png" class="logo"> <!-- Première image -->
    <img src="upload/Quentin_Tarantino_by_Gage_Skidmore.jpg" class="logo"> <!-- Deuxième image -->
    <p> 15/20 : Facilement modifiable, codes bien organisés</p>    
    <h2>Quentin Caron</h2>
        <h2>Groupe : Yanis et Vladimir</h2>
        <br>
    <bouton class="bouton_link">
        <a class="link" href="upload.php">
            Upload your file
        </a>
    </bouton>
    <?php include 'footer.html';?>
    </div>
</body>
</html>
