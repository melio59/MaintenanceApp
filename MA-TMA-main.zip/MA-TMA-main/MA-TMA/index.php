<!doctype html>
<html lang="fr">
<head>
    <link rel="stylesheet" href="styles.css">
    <meta charset="utf-8">
    <title>Accueil</title>
</head>
<body>
    <div class="container">
        <div class="profile-section">
            <img src="image/michelle.png" alt="Photo de Michelle Télo" class="profile-photo">
            <h2>Télo Thomas</h2>
            <a href="upload_form.php" class="upload-button">Uploader vos fichiers ici</a>
        </div>
    </div>
</body>
</html>
